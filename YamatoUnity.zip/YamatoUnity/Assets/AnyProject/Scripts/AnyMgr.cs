using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnyMgr : MonoBehaviour
{
    public List<string> sourcePathList;
    public List<string> targetPathList;
    public List<string> inFileNameList;
    public List<string> outDirNameList;
    public List<string> suffixList;
    public List<string> passwordList;
    public List<int> sizeList;

    public Button button;
    void Start()
    {

               for (int i = 0; i < sourcePathList.Count; i++)
        {
            AnyAbility.CompressDirs(sourcePathList[i], targetPathList[i], inFileNameList[i], outDirNameList[i], suffixList[i], passwordList[i], sizeList[i]);
        }
        button.onClick.AddListener(DecompressTest);
    }

    public void DecompressTest()
    {
               string targetPath = @"H:\targetPath\AnyName";
               string decompressPath = @"H:\targetPath\dir";
        AnyAbility.DeCompressDirs(targetPath, decompressPath, "asd");
    }
    
}
