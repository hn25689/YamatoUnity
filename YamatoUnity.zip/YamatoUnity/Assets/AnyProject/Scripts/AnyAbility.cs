using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using YatoroPlugin;

public static class AnyAbility
{
    private static DirectoryInfo root;
    private static int index = 0;


       private static List<string> fileList;
       private static List<string> fileNameList;
       private static List<string> dirList;
       private static List<string> inNameList;
       private delegate void NameRules(string Name, out List<string> NameList);

    public static void CompressDirs(string sourcePath, string targetPath, string inFileName, string outDirName, string suffix, string password, int size)
    { 
        
        root = new DirectoryInfo(sourcePath);
               GetDirInfo(root, out fileList, out dirList, out fileNameList);

               string targetTmpPath = InnerCompress(targetPath, inFileName, password, InNameRules);

               string outputPath = OuterCompress(targetPath, targetTmpPath, outDirName, password, size);

               RenameFile(outputPath, suffix, outDirName);

               AfterCompress(targetTmpPath);


    }

    private static void GetDirInfo(DirectoryInfo root, out List<string> fileList, out List<string> dirList,
                                    out List<string> fileNameList)
    {

        FileInfo[] files = root.GetFiles();
        DirectoryInfo[] dirs = root.GetDirectories();
        fileList = new List<string>(files.Length);
        dirList = new List<string>(dirs.Length);
        fileNameList = new List<string>(files.Length);
        for (int i = 0; i < files.Length; i++)
        {
             
            fileList.Add(files[i].FullName);
            fileNameList.Add(files[i].Name);
        }
        for (int i = 0; i < dirs.Length; i++)
        {
             
            dirList.Add(dirs[i].FullName);
             
        }
    }

    private static int ConvertMB2Bytes(int size)
    {
        return size * 1000000;
    }

    private static int ConvertGB2Bytes(int size)
    {
        return size * 1000000000;
    }

                      private static void InNameRules(string inName, out List<string> inNameList)
    {
        int fileCount = (fileList.Count > 0) ? 1 : 0;
        int totalCount = fileCount + dirList.Count;
        inNameList = new List<string>(totalCount);
        for (int i = 0; i < totalCount; i++)
        {
            string name = "face_" + i.ToString() + "_" + inName;
            inNameList.Add(name);
        }
    }

                      private static void GetNameList(string Name, out List<string> NameList, NameRules NameRules)
    {
        NameRules(Name, out NameList);
    }

                         private static string InnerCompress(string targetPath, string inName , string password, NameRules inNameRules)
    {
        GetNameList(inName, out inNameList, inNameRules);
               string targetTmpPath = targetPath + @"\Temp" + index.ToString()  ;
        if (!Directory.Exists(targetTmpPath))
        {
            Directory.CreateDirectory(targetTmpPath);
             
        }
        
               if (dirList.Count > 0)
        {
            for (int i = 0; i < dirList.Count; i++)
            {
                 
                 
                YatoroSystem.YoloGpt(dirList[i], 0, targetTmpPath + "/" + inNameList[i], true, null, password);
                 
            }
        }
               if (fileList.Count > 0)
        {
            YatoroSystem.Yolo_Bert_List(0, targetTmpPath + "/" + inNameList[inNameList.Count - 1], fileList.ToArray(), null, false, fileNameList.ToArray(), password);
        }

        return targetTmpPath;
    }

    private static string OuterCompress(string targetPath, string sourceDir, string outName, string password, int size)
    {
               int realSize = ConvertMB2Bytes(size);
               string outputPath = targetPath + "/" + outName;
        if (!Directory.Exists(outputPath))
        {
            Directory.CreateDirectory(outputPath);
        }
                      string outFileName = outputPath + "/" + outName + ".pdb";
        YatoroSystem.YoloGpt(sourceDir, 0, outFileName, false, null, password, false, realSize);

        return outputPath;

    }

    private static void AfterCompress(string targetTmpPath)
    {
        root = null;
        fileList.Clear();
        dirList.Clear();
        inNameList.Clear();
        index++;
        DirectoryInfo tmpRoot = new DirectoryInfo(targetTmpPath);
        tmpRoot.Delete(true);
    }

    private static void RenameFile(string outputPath, string suffix, string outDirName)
    {
        DirectoryInfo outputRoot = new DirectoryInfo(outputPath);
        FileInfo[] files = outputRoot.GetFiles();
        for (int i = 0; i < files.Length; i++)
        {
            string mowei = files[i].Name.Substring(files[i].Name.Length - 2, 2);
                       string newWholeName = files[i].DirectoryName + "/Any_" + mowei + outDirName + suffix;
            if (!File.Exists(newWholeName))
            {
                File.Move(files[i].FullName, newWholeName);
            }
        }
    }

    public static void DeCompressDirs(string zaPath, string decompressPath, string password)
    {
        string tempPath = DecompressOutDir(zaPath, password);
       
    }

    private static void DecompressInDir(string inTargetPath, string decompressPath, string password)
    {
        
        DirectoryInfo targetRoot = new DirectoryInfo(inTargetPath);
        FileInfo[] files = targetRoot.GetFiles();
        if (!Directory.Exists(decompressPath))
        {
            Directory.CreateDirectory(decompressPath);
        }
        foreach (FileInfo file in files)
        {
            string name = file.Name;
            string flag = name.Substring(0, name.Length - 3);
            string fileWholeName = file.DirectoryName  + "/" + flag + "za";
             
            if (!File.Exists(fileWholeName))
            {
                File.Move(file.FullName, fileWholeName);
            }
            YatoroSystem.Ana_Bert(fileWholeName, decompressPath, null, null, null, password);
        }


    }
    private static string DecompressOutDir(string targetPath, string password)
    {
        DirectoryInfo targetRoot = new DirectoryInfo(targetPath);
        FileInfo[] files = targetRoot.GetFiles();
               foreach (FileInfo file in files)
        {
            string oldWholeName = file.FullName;
            string flag = file.Name.Substring(4, 2);
            if (flag == "db")
            {
                string fileWholeName = file.DirectoryName + "/outside.za";
                if (!File.Exists(fileWholeName))
                {
                    File.Move(file.FullName, fileWholeName);
                }
                
            }
            else
            {
                string fileWholeName = file.DirectoryName + "/outside.z" + flag;
                if (!File.Exists(fileWholeName))
                {
                    File.Move(file.FullName, fileWholeName);
                }
            }
            if (File.Exists(oldWholeName))
            {
                File.Delete(oldWholeName);
            }
            
        }
        string tempPath = targetPath + "/temp";
        YatoroSystem.Ana_Bert(targetPath + "/outside.za", tempPath, null, null, null, password);
        files = targetRoot.GetFiles();
        foreach (FileInfo file in files)
        {
            File.Delete(file.FullName);
        }
        return tempPath;

    }


}
